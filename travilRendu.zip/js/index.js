const btn = document.getElementById('btn-subscribe');
btn.addEventListener('click', (e) => {
  e.preventDefault();
  alert('le formulaire a été soumis avec succès')
})